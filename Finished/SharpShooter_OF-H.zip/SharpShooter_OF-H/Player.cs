﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace SharpShooter_OF_H
{
    public class Player : Soldier
    {
        public Player(PointF location) : base("Images/Player.png", location)
        {
            this.currentWeapon = new RapidGun(this.location);
        }

        public void KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                turnDirc = 0.1f;
            }


            if (e.KeyCode == Keys.Right)
            {
                turnDirc = -0.1f;
            }

            if (e.KeyCode == Keys.Up)
            {
                walkDirc = 1;
            }

            if (e.KeyCode == Keys.Down)
            {
                walkDirc = -1;
            }

            if (e.KeyCode == Keys.Z)
            {
                isFiring = true;
            }
        }


        public void KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                turnDirc = 0;
            }

            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                walkDirc = 0;
            }

            if (e.KeyCode == Keys.Z)
            {
                isFiring = false;
            }
        }

    }
}







