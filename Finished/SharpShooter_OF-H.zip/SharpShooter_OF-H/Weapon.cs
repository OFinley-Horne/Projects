﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SharpShooter_OF_H
{
     public abstract class Weapon
    {
        public PointF location;
        public Picture pic;

        public float bulletSpeed;
        public float facingAngle;
        public int fireDelay;
        public int timeSinceLastShot = 0;
        public int bulletStartDistance;

        //public int damage

        public Weapon(string weaponImage, PointF location)
        {
            this.pic = new Picture(weaponImage, location, 1, 1);
            this.location = location;


        }


        public void Draw(Graphics g)
        {
            pic.angle = this.facingAngle;

            pic.location.X = this.location.X - MainForm.viewOffset.X;
            pic.location.Y = this.location.Y - MainForm.viewOffset.Y;

            pic.Draw(g);
        }

            
        public void Fire(Soldier personFiring)
        {
            //Stops player from shooting to early
            if (timeSinceLastShot < fireDelay)
            {
                return;
            }
            timeSinceLastShot = 0;
            //find the player's angle to give to the bullet at the moment it's fired
            float xComponent = (float)Math.Cos(facingAngle / 180 * Math.PI);
            float yComponent = -(float)Math.Sin(facingAngle / 180 * Math.PI);

            //Create the bulletstarting from the player's location
            Bullet b = CreateBullet(personFiring);

            b.location.X = personFiring.location.X + xComponent * this.bulletStartDistance;
            b.location.Y = personFiring.location.Y + xComponent * this.bulletStartDistance;


            //Give the bulet a velocity so it moves
            b.velocity.X = xComponent * bulletSpeed;
            b.velocity.Y = yComponent * bulletSpeed;


        }

        public void update(int time)
        {
            timeSinceLastShot += time;
        }

        public abstract Bullet CreateBullet(Soldier personFiring);
    }
   
}
