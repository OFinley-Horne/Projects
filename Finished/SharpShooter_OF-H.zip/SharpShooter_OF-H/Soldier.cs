﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace SharpShooter_OF_H
{
    public class Soldier
    {
        public PointF location;
        public Picture pic;
        public float facingAngle;
        public float turnDirc = 0; // negative when rotating left, positive when rotationg right, 0 when not rotating
        public int walkDirc = 0; // negative when moving bakcwards, postive when moving forawrds, 0 when not moving  
        public PointF velocity;
        public int moveSpeed = 10;
        public float bulletSpeed = 15f;
        public bool isFiring = false;
        public int fireDelay = 500;
        public int timeSinceLastShot = 0;
        public float bulletStartDistance = 30f;
        public int radius;
        public int HP = 5;
        public bool killed = false;
        public bool hitFlicker = false;
        public int hitFlickerCount = 0;
        public Weapon currentWeapon;


        public Soldier(String image, PointF location)
        {
            this.location = location;

            pic = new Picture(image, location, 4, 60);
            velocity = new PointF();

            Random r = new Random((int) DateTime.Now.Ticks);
            facingAngle = r.Next(360);

            radius = pic.bitmap.Width / 2;
        }

        public void Draw(Graphics g)
        {
            if (this.killed)
            {
                return;
            }

            pic.angle = facingAngle;

            if (!hitFlicker) // if hitflicker = false, !hitflicker = true but if hitflicker = true, hitflicker = false
            {
                pic.location.X = location.X - MainForm.viewOffset.X;
                pic.location.Y = location.Y - MainForm.viewOffset.Y;
                pic.Draw(g);

                currentWeapon.Draw(g);
            }

        }

        public virtual void Update(int time)
        {
            if (HP <= 0)
            {
                killed = true;
                Explosion e = new Explosion(this.location);
                return;
            }

            if (hitFlickerCount > 0){
                hitFlickerCount --;
                hitFlicker = !hitFlicker;
                
            }
            else
            {
                hitFlicker = false;
            }

            facingAngle += (float)(time) * turnDirc;

            // calculate the velocity based on the facing angle
            velocity.X = (float)Math.Cos(facingAngle / 180f * Math.PI) * walkDirc * moveSpeed;
            velocity.Y = -(float)Math.Sin(facingAngle / 180f * Math.PI) * walkDirc * moveSpeed;

            Move();


            if (this.velocity.X !=0 || this.velocity.Y != 0)
            {
                pic.update(time);
            }

            this.UpdateWeapon(time);

            if (isFiring == true)
            {
                currentWeapon.Fire(this);
            }

            foreach(Wall w in MainForm.wallList)
            {
                PointF touchPoint = new PointF();
                if(this.isTouchingWall(w, ref touchPoint))
                {
                    pushFrom(touchPoint);
                }

            }

        }


        public void UpdateWeapon(int time)
        {
            float xOffset = (float)Math.Cos(this.facingAngle / 180f * Math.PI) * 32f;
            float yOffset = -(float)Math.Sin(this.facingAngle / 180f * Math.PI) * 32f;


            currentWeapon.location.X = this.location.X + xOffset;
            currentWeapon.location.Y = this.location.Y + yOffset;

            currentWeapon.facingAngle = this.facingAngle;
            currentWeapon.update(time);
        }

        public void Move()
        {
            location.X += velocity.X;
            location.Y += velocity.Y;
        }


  


        public void TakeDamage(int damage)
        {
            HP -= damage;
            hitFlickerCount = 4;
        }



        public bool isTouchingWall(Wall w, ref PointF touchPoint)
        {
            PointF nearestPoint = w.PointNearestTo(this.location);
            float a = nearestPoint.X - this.location.X;
            float b = nearestPoint.Y - this.location.Y;

            float distance = (float) Math.Sqrt(a * a + b * b);

            if(distance < radius)
            {
                touchPoint = nearestPoint;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void pushFrom(PointF p)
        {
            float a = p.X - this.location.X;
            float b = p.Y - this.location.Y;
            float actualDistance = (float)Math.Sqrt(a * a + b * b);

            if (actualDistance == 0)
            {
                return;
            }


            float desiredDistance = this.radius + 1;

            float proportion = desiredDistance / actualDistance;
            PointF move = new PointF(this.location.X - p.X, this.location.Y - p.Y);
            move.X *= proportion;
            move.Y *= proportion;

            this.location.X = p.X + move.X;
            this.location.Y = p.Y + move.Y;

        }


    }




}
