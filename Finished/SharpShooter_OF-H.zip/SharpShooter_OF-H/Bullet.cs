﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SharpShooter_OF_H
{
    public class Bullet
    {

       
        public PointF location;
        public PointF velocity;
        public Picture pic;
        public float life = 1.0f; // The lifespan of a fired bullet, in seconds
        public int radius;
        public Soldier parent;
        public Bullet(string image, Soldier s, PointF location)
        {
             
            pic = new Picture(image, location, 4, 60);
            velocity = new PointF();
            this.location = location;
            MainForm.bulletList.Add(this);
            radius = pic.bitmap.Width/2;
            this.parent = s;

           
        }

        public void Update(int time)
        {
            Move();
            pic.update(time);

            life -= time/1000f; 

            if (life <= 0)
            {
                MainForm.bulletList.Remove(this);

            }



            foreach(Wall w in MainForm.wallList)
            {
                if (this.isTouchingWall(w))
                {
                    this.backUpPostion();

                    PointF normal = w.normalAtNearestPoint(this.location);
                    this.bounceFrom(normal);
                }
            }

            if(this.parent == MainForm.player1)
            {

                //Looopos for every enemy in enemyList
                for (int i = 0; i < MainForm.enemyList.Count; i++)
                {
                    if (this.isTouching(MainForm.enemyList[i]))
                    {
                        MainForm.bulletList.Remove(this);
                        MainForm.enemyList[i].TakeDamage(1);
                    }
                }

      
            }
            if (this.parent != MainForm.player1)
            {

                if (this.isTouching(MainForm.player1))
                {
                    MainForm.bulletList.Remove(this);
                    MainForm.player1.TakeDamage(1);
                }
            }
        }


        public virtual void Draw(Graphics g)
        {
 
            pic.location.X = location.X - MainForm.viewOffset.X;
            pic.location.Y = location.Y - MainForm.viewOffset.Y;
            pic.Draw(g);
        }

        public virtual void Move()
        {
            location.X += velocity.X;
            location.Y += velocity.Y;
        }
    
        public bool isTouching(Soldier s)
        {
            double a = s.location.X - this.location.X;
            double b = s.location.Y - this.location.Y;
            double distance = Math.Sqrt(a * a + b * b);

            int maxTouchtingDIstance = s.radius + this.radius;

            if(distance > maxTouchtingDIstance){
                return false; 
            }
            else
            {
                return true;
            }


        
        }
        public bool isTouchingWall(Wall w)
        {


            PointF nearestPoint = w.PointNearestTo(this.location);

            float a = nearestPoint.X - this.location.X;
            float b = nearestPoint.Y - this.location.Y;
            float distance = (float) Math.Sqrt(a * a + b * b);




            if (distance < radius)
            {
                return true;
            }
            else
            {
                return false;
            }


        }


        public void backUpPostion()
        {
            this.location.X -= velocity.X;
            this.location.Y -= velocity.Y;
        }



        public void bounceFrom(PointF normal)
        {
            PointF R;

            float b = (velocity.X * normal.X + velocity.Y * normal.Y);

            b *= 2;

            R = new PointF(this.velocity.X - normal.X * b, this.velocity.Y - normal.Y*b);


            this.velocity.X = R.X;
            this.velocity.Y = R.Y;

        }
    }
}
