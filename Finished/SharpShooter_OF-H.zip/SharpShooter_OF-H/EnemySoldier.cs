﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SharpShooter_OF_H
{
    public class EnemySoldier : Soldier
    {
        public int directionChangeCount = 0;
        public int nextDirectionChange = 0;

        public EnemySoldier (PointF location) :base("Images/Enemy1.png", location)
        {
            
            MainForm.enemyList.Add(this);
            isFiring = true;
            walkDirc = 1;

            this.currentWeapon = new Pistol(this.location);

            Random r = new Random((int)DateTime.Now.Ticks + (int)this.location.X);
            nextDirectionChange = r.Next(500) + 2000; //Between 2and 2.5seconds approx
        }

        public override void Update(int time)
        {
            base.Update(time);
            if (this.killed == true)
            {
                MainForm.enemyList.Remove(this);
            }

            directionChangeCount += time;

            if (directionChangeCount >= nextDirectionChange)
            {
                Random r = new Random();
                facingAngle = r.Next(360);

                directionChangeCount = 0;
                nextDirectionChange = r.Next(500) + 2000;
            }
            
        }
    }
}
