﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace SharpShooter_OF_H
{
    public class Level
    {
        public static void initLists()
        {
            MainForm.enemyList = new List<EnemySoldier>();
            MainForm.bulletList = new List<Bullet>();
            MainForm.wallList = new List<Wall>();
            MainForm.explosionList = new List<Explosion>();
        }

        public static void createBorders(int topX, int topY, int width, int height)
        {
            Wall borderTop = new Wall("Blue", topX - 80, topY - 80, width + 80, 80);
            Wall borderBottom = new Wall("Blue", topX, topY + height, width + 80, 80);
            Wall borderLeft = new Wall("Blue", topX - 80, topY, 80, height + 80 );
            Wall borderRight = new Wall("Blue", topX + width, topY - 80, 80, height + 80);
        }

        public static void CreateWalls()
        {
            Wall wall1 = new Wall("Green", 150, 250, 300, 30);
            Wall wall2 = new Wall("Green", 550, 150, 30, 30);
        }
        public static void createEnemies()
        {
            EnemySoldier e1 = new EnemySoldier(new PointF(300, 250));
            EnemySoldier e2 = new EnemySoldier(new PointF(200, 250));
            EnemySoldier e3 = new EnemySoldier(new PointF(600, 250));
            EnemySoldier e4 = new EnemySoldier(new PointF(200, 130));
        }

        public static void createLevel()
        {
            MainForm.player1 = new Player(new PointF(0,0));

            initLists();
            createBorders(-800, -800, 1600, 1600);
            CreateWalls();
            createEnemies();
        }

      
    }   
   
}
