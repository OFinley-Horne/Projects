﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SharpShooter_OF_H
{
    public class RapidGun: Weapon
    {

        public RapidGun(PointF location) : base("Images/RapidGun.png", location)
        {
            this.bulletSpeed = 15f;
            this.bulletStartDistance = 0;
            this.fireDelay = 200;
        }

        public override Bullet CreateBullet(Soldier personFiring)
        {
            return new Bullet("Images/Bullet3.png", personFiring, new PointF());
        }
    }
}
