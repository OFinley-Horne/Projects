﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SharpShooter_OF_H
{
    public class Pistol: Weapon
    {
        public Pistol(PointF location): base("Images/Pistol.png", location)
        {
            this.bulletSpeed = 15f;
            this.bulletStartDistance = 20;
            this.fireDelay = 600;
        }

        public override Bullet CreateBullet(Soldier personFiring)
        {
            return new Bullet("Images/Bullet1.png", personFiring, new PointF());
        }

    }
}
