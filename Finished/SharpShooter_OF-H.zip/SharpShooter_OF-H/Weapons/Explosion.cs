﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace SharpShooter_OF_H
{
    public class Explosion
    {

        public Picture pic;
        public PointF location;
        public int life = 240;
        public Explosion(PointF location)
        {
            pic = new Picture("Images/Explode.png", location, 6, life/6);
            this.location = location;
            MainForm.explosionList.Add(this);
        }

        public void Draw(Graphics g)
        {
            pic.location.X = this.location.X - MainForm.viewOffset.X;
            pic.location.Y = this.location.Y - MainForm.viewOffset.Y;

            pic.Draw(g);
        }
        

        public void Update(int time)
        {
            life -= time;
            if(life <= 0)
            {
                MainForm.explosionList.Remove(this);
            }
            pic.update(time);
        }
    }
}
