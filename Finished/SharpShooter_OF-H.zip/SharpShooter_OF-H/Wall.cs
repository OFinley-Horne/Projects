﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;


namespace SharpShooter_OF_H
{
    public class Wall
    {

        int left;          
        int top;
        int width;
        int height;

        Bitmap image;
        
        public Wall(string colour, int left, int top, int width, int height)
        {

            this.left = left;
            this.top = top;
            this.width = width;
            this.height = height;
            image = new Bitmap("Images/" + colour + "Box.png");
            MainForm.wallList.Add(this);
        }

        public void Draw(Graphics g)
        {
            g.Transform = new Matrix();
            g.DrawImage(image, new Rectangle(left - MainForm.viewOffset.X, top - MainForm.viewOffset.Y, width, height));
        }

        public PointF PointNearestTo(PointF p)
        {
            PointF nearestPoint = new PointF();


            if(this.left > p.X)
            {
                nearestPoint.X = this.left;
            }

            else if(this.left + this.width < p.X)
            {
                nearestPoint.X = this.left + this.width;
            }

            else
            {
                nearestPoint.X = p.X;
            }


            if(this.top > p.Y)
            {
                nearestPoint.Y = this.top;
            }
            

            else if(this.height + this.top < p.Y)
            {
                nearestPoint.Y = this.height + this.top;
            }
            else
            {
                nearestPoint.Y = p.Y;
            }



            return nearestPoint;
        }



        public PointF normalAtNearestPoint(PointF p)
        {
            PointF nearestPoint = this.PointNearestTo(p);



            PointF normal = new PointF ();


            normal.X = p.X - nearestPoint.X;
            normal.Y = p.Y - nearestPoint.Y;

            if (normal.X == 0 && normal.Y == 0)
            {
                return normal;
            }

            float invers = 1f / (float)Math.Sqrt(normal.X * normal.X + normal.Y * normal.Y);

            normal.X *= invers;
            normal.Y *= invers;

            return normal;
        }

    }
}
