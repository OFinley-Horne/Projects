﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SharpShooter_OF_H
{
    public partial class MainForm : Form
    {
        public static Player player1;
        public static List<EnemySoldier> enemyList;
        public static List<Bullet> bulletList;
        public static List<Wall> wallList;
        public static List<Explosion> explosionList;
        

        
        Graphics windowsGraphics;
        Graphics onScreenGraphics;
        Bitmap screen;


        public Picture gameOverScreen;
        public Picture victoryScreen;
        public static Point viewOffset;
        public MainForm()
        {
            InitializeComponent();
            windowsGraphics = this.CreateGraphics();
            screen = new Bitmap(this.Width, this.Height);
            onScreenGraphics = Graphics.FromImage(screen);
            // set our DrawGame method to activate when the screen is repainted
            this.Paint += new PaintEventHandler(DrawGame);
         
        }

        void Init()
        {
            Level.createLevel();

            gameOverScreen = new Picture("Images/GameOver.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);
            victoryScreen = new Picture("Images/Victory.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);

            // sets the keydown method in the Player class to be run once a key is pressed
            this.KeyDown += new KeyEventHandler(player1.KeyDown);
            this.KeyUp += new KeyEventHandler(player1.KeyUp);
             
        }


        public void DrawGame(object sender, PaintEventArgs e)
        {
            if (!GameTimer.Enabled)
            {
                return;
            }
            onScreenGraphics.Clear(Color.Black);
            player1.Draw(onScreenGraphics);
            foreach(Bullet b in bulletList){

                b.Draw(onScreenGraphics);
            }
            foreach (Soldier s in enemyList)
            {

                s.Draw(onScreenGraphics);
            }
            foreach (Wall w in wallList)
            {
                w.Draw(onScreenGraphics);
            }
            foreach (Explosion ex in explosionList)
            {
                ex.Draw(onScreenGraphics);
            }



            if (player1.killed == true)
            {
                gameOverScreen.Draw(onScreenGraphics);
            }

            if (enemyList.Count == 0)
            {
                victoryScreen.Draw(onScreenGraphics);
            }


            // Draw the bffer ont he application using windowsGraphics
            windowsGraphics.DrawImage(screen, new Point(0, 0));

          

        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            player1.Update(GameTimer.Interval);
            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletList[i].Update(GameTimer.Interval);
            }
            for (int i = 0; i < enemyList.Count; i++)
            {
                enemyList[i].Update(GameTimer.Interval);
            }
            for (int i = 0; i < explosionList.Count; i++)
            {
               explosionList[i].Update(GameTimer.Interval);
            }

            viewOffset.X = (int)player1.location.X - this.Width/2;
            viewOffset.Y = (int)player1.location.Y - this.Height/2;

            OnPaint(new PaintEventArgs(windowsGraphics, new Rectangle(0, 0, this.Width, this.Height)));
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            Init();
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void playLabel_Click(object sender, EventArgs e)
        {
            Init();
            GameTimer.Enabled = true;

            title.Hide();
            playLabel.Hide();
        }
    }
}
